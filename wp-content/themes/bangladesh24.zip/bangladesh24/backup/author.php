<?php get_header(); ?>


<?php _e('hello'); ?>





<?php get_footer(); ?>