<?php if ( is_active_sidebar( 'prayer_time' ) ) : ?>
	<div id="prayer-sidebar" class="prayer-sidebar widget-area" role="complementary">
		<?php dynamic_sidebar( 'prayer_time' ); ?>
	</div><!-- #primary-sidebar -->
<?php endif; ?>


