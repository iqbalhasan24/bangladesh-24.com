<?php

/**
Plugin Name: Better BirdEye Reviews
description: Custom plugin to display reviews from the BirdEye API.  TODO: Add customization options for color, templates, etc.
Version: 1.0
Author: Matthew Scheppmann
License: GPLv2 or later
Text Domain: github-api
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

function fetch_business_func() {
  $source[]          = !empty($_POST['source']) ? $_POST['source'] : "All";	
  $data              = array('sources' => $source);
  $opts              = array(
      'http'         => array(
          'method'   => 'GET',
          'header'   => "Content-Type: application/json\r\n" . 
          "Accept: application/json\r\n",
          //'content'  => json_encode($data)
      )
  );
  $context           = stream_context_create($opts);
  $url               = 'https://api.birdeye.com/resources/v1/business/152921176367988?api_key=VY4s1Ag7wCZPYSeMQ2btkFswiGL0rMrr';
  $response          = file_get_contents( $url, false, $context );
  $theBusiness       = json_decode($response);
  //return $theBusiness;
  exit();
}

function fetch_review_stars_func($ratingAmount) {
  $reviewPercentage = $ratingAmount / 5 * 100;
  $starincr = 0;
  //' .($starincr < $ratingAmount ? 'star-active' : 'star-inactive') .'
  $starReturn = '  
  <div class="bbr-star-rating" title="'.$reviewPercentage.'%">
    <div class="back-stars">
      <i class="fa fa-star" aria-hidden="true"></i>
      <i class="fa fa-star" aria-hidden="true"></i>
      <i class="fa fa-star" aria-hidden="true"></i>
      <i class="fa fa-star" aria-hidden="true"></i>
      <i class="fa fa-star" aria-hidden="true"></i>
      
      <div class="front-stars" style="width: '.$reviewPercentage.'%">
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
        <i class="fa fa-star" aria-hidden="true"></i>
      </div>
    </div>
  </div>  
  ';  
  
  return $starReturn;
}
function fetch_review_summary_func($businessid) {
  $source[]          = !empty($_POST['source']) ? $_POST['source'] : "All";	
  $data              = array('sources' => $source);
  $reviewSummaryOpts = array(
      'http' => array(
          'method' => 'GET',
          'header' => "Content-Type: application/json\r\n" .  
          "Accept: application/json\r\n",
          'content'=> json_encode($data)
      )
  );
  $reviewSummaryContext  = stream_context_create($reviewSummaryOpts);
  $reviewSummaryURL      = 'https://api.birdeye.com/resources/v1/review/businessid/'.$businessid.'/summary?api_key=VY4s1Ag7wCZPYSeMQ2btkFswiGL0rMrr&statuses=published&statuses=parked';
  // die($businessid);
  $reviewSummaryResponse = file_get_contents( $reviewSummaryURL, false, $reviewSummaryContext );


  if( is_wp_error( $reviewSummaryResponse ) ) {
    return false; // Bail early
  }
  
  $reviewSummaryData     = json_decode($reviewSummaryResponse);
  $reviewNumber = $reviewSummaryData->avgRating;
  
  $reviewSummaryHtml = '';
  if( ! empty( $reviewSummaryData ) ) {
    $reviewSummaryHtml .= '
    <div class="bbr-avg-rating-container"><span class="bbr-avg-rating">'.$reviewSummaryData->avgRating.'</span></div>
    <div class="bbr-avg-review-total-container"><span class="bbr-avg-review-total">Based on '.$reviewSummaryData->reviewCount.' reviews.</span></div>
    <div class="summary-star-container">
    '.fetch_review_stars_func($reviewNumber).'
    </div>';
  }
  
  return $reviewSummaryHtml;
  exit();
}

function review_sort_func($a,$b) {
     return $a['comments']<$b['comments'];
}

function fetch_reviews_func($businessid, $color, $reviewlength, $reviewcount) {
  $source[] = !empty($_POST['source']) ? $_POST['source'] : "All";	
  $data = array('sources' => $source);
  /* The Reviews Request */
  $reviewFeedOpts = array(
      'http' => array(
          'method' => 'POST',
          'header' => "Content-Type: application/json\r\n" .  
          "Accept: application/json\r\n",
          'content'=> json_encode($data)
      )
  );
  $reviewFeedContext = stream_context_create($reviewFeedOpts);
  $reviewFeedURL = 'https://api.birdeye.com/resources/v1/review/businessId/'.$businessid.'?sindex=0&count='.$reviewcount.'&api_key=VY4s1Ag7wCZPYSeMQ2btkFswiGL0rMrr';
  $reviewFeedResponse = file_get_contents( $reviewFeedURL, false, $reviewFeedContext );
  


  if( is_wp_error( $reviewFeedResponse ) ) {
    return false; // Bail early
  }
  $objReviews = json_decode($reviewFeedResponse, true);
  
  //$objReviews = json_decode($reviewFeedResponse, true);
  //usort($objReviews, "review_sort_func");
  
  
  
  $reviewerHtml='';
  if( ! empty( $objReviews ) ) {
    $reviewerHtml.='<div class="bbr-container">';
    if( $color != '' ) {
      echo '
      <style type="text/css">
        .bbr-review-name, .front-stars {
          color: '.$color.'!important;
          border-color: '.$color.'!important;
        }
      </style>
      ';
    }
    foreach( $objReviews as $objReview ) {
        $objReview['sourceType'] = $objReview['sourceType'] == 'Our Website' ? "BirdEye" : $objReview['sourceType'];
        $reviewerImg = $objReview['reviewer']['thumbnailUrl'];
        $reviewerName = !empty($objReview['reviewer']['firstName']) ? $objReview['reviewer']['firstName'] : $objReview['reviewer']['nickName'];
        $starcount = $objReview['rating'];
        $starincr = 0;
        $thereviewcomments = $objReview['comments'];
        $max_length = $reviewlength;

        if (strlen($thereviewcomments) > $max_length)
        {
            $offset = ($max_length - 3) - strlen($thereviewcomments);
            $thereviewcomments = substr($thereviewcomments, 0, strrpos($thereviewcomments, ' ', $offset)) . '...';
        }
          //if(!$objReview->comments == '' || !$objReview->comments == null){
          if ($starcount >= 4) {
          $reviewerHtml.='      
            <div class="bbr-row">
              <div class="bbr-review-author">
                <img src="' .$reviewerImg .'" class="bbr-review-thumbnail">
                <p class="bbr-review-name">' .$reviewerName .'</p>
                <p class="bbr-review-date"><em>' .$objReview['reviewDate'] .'</em></p>
              </div>
              <div class="bbr-review-column">
                <div class="bbr-review-stars">
                  '.fetch_review_stars_func($starcount).'
                </div>
                <p class="bbr-review-text">' .$thereviewcomments.'</p>
              </div>
            </div>';
            }
            //}
          }
          $reviewerHtml.='</div>';
        }

   return $reviewerHtml;
   exit();
}

function enqueue_your_styles() {
    $plugin_url = plugin_dir_url( __FILE__ );
    wp_enqueue_style( 'style',  $plugin_url . "css/style.min.css");
}

add_action( 'wp_enqueue_scripts', 'enqueue_your_styles', 20 );

ob_start();
function better_birdeye_reviews_plugin( $atts = [] ) {
  $atts = array_change_key_case((array)$atts, CASE_LOWER);
	$sc_atts = shortcode_atts( 
    array(
  		'location' => 'xxx',
      'color' => '#000',
      'maxlength' => '350',
  		'reviewcount' => '15',
      'summary' => '1',
  	), 
    $atts,
    'reveal'
  ); 
  $bbrOutput='';
  if ($sc_atts['summary'] == '1') {
    $bbrOutput.=fetch_review_summary_func($sc_atts['location']);
  }
  if ($sc_atts['location'] != 'xxx') {
    $bbrOutput.=fetch_reviews_func($sc_atts['location'], $sc_atts['color'], $sc_atts['maxlength'], $sc_atts['reviewcount']);
  } else {
    echo '<strong>It appears the location id is invalid, please ensure you have defined the id when using the shortcode!';
  }
  
  $bbrOutput.='<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/solid.css" integrity="sha384-osqezT+30O6N/vsMqwW8Ch6wKlMofqueuia2H7fePy42uC05rm1G+BUPSd2iBSJL" crossorigin="anonymous">';
  $bbrOutput.='<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/fontawesome.css" integrity="sha384-BzCy2fixOYd0HObpx3GMefNqdbA7Qjcc91RgYeDjrHTIEXqiF00jKvgQG0+zY/7I" crossorigin="anonymous">';
  return $bbrOutput;
}
ob_end_clean();
add_shortcode( 'birdseye_reviews', 'better_birdeye_reviews_plugin' );
