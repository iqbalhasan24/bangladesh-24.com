<?php
function __construct( $config ) {
	$this->providers = $config['providers'];
	$this->provider = $config['provider'];
  // Actions and filters here
}
