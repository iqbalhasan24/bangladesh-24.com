<?php
$config = array(
  'api_key' => 'cd64539dd19283cdcc637f2ccddcd45-us6'
);

class MySubscriptionForm {
  var $api_key;

  function __constructor( $config ) {
    $this->api_key = $config['api_key'];
  }

}

new MySubscriptionForm( $config );