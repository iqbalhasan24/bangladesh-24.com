<?php
function __construct( $config ) {
	$this->api_key = $config['api_key'];

	add_filter( 'the_content', array( $this, 'form' ) );
	add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
	add_action( 'wp_ajax_msf_form_submit', array( $this, 'submissionHandler' ) );
	add_action( 'wp_ajax_nopriv_msf_form_submit', array( $this, 'submissionHandler' ) );
}
