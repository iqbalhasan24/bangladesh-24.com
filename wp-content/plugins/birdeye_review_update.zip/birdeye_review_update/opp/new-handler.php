<?php
wp_remote_post('https://us6.api.mailchimp.com/3.0/lists/bbcd6546db/members', array(
    'headers' => array(
        'Authorization' => 'Basic ' . base64_encode( 'mywebsite' . ':' . $this->providers['mailchimp']['api_key'] ),
        'Content-Type' => 'application/json'
    ),
    'body' => json_encode( array(
        'email_address' => $_POST['email'],
        'status' => 'subscribed'
    ))

));