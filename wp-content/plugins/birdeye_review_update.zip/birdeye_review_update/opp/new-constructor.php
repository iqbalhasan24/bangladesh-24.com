<?php
var $providers;

function __construct( $config ) {
	$this->providers = $config['providers'];
 	// rest of the constructor
}
