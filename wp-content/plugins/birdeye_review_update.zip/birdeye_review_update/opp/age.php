add_filter( 'msf/form_fields', 'age_field_extension' );

function age_field_extension( $fields ) {
	$fields[] = '<input type="text" placeholder="Age" name="age">';
	return $fields;
}
