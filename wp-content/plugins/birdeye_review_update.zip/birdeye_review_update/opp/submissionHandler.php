<?php
function submissionHandler() {
	if( method_exists($this, $this->provider . 'Handler' ) ) {
        call_user_func( array( $this, $this->provider . 'Handler' ) );
	}
    else {
        echo $this->provider . 'Handler does not exist' ;
    }
}
