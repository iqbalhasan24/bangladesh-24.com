<?php
$config = array(
  'providers' => array(
    'mailchimp' => array(
      'api_key' => 'cd64539dd19283cdcc637f2ccddcd45-us6'
    ),
    'madmimi' => array(
      'api_key' => 'JBJiwneJKNJBEhbfwbj2983hu43e'
    )
  )
);
